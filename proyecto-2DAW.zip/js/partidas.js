//Carga los script
cargarScripts();

window.onload = function () {
    //Creamos el header
    crearHeader();
    crearFooter();
    //Creamos el mapa
    crearMapa();
};