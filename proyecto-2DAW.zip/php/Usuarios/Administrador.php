<?php
include("bd.php"); // En un futuro se reemplazará con autocarga
class Administrador extends usuario{

    // PERFILES

    public function CargarCambiosPerfilTodos(){
        
    }
    public function CambiarRol($usuario, $rolActual){
        
    }

    // PRODUCTOS

    public function editarProducto(){
        
    }
    public function eliminarProducto(){
        
    }
    public function crearProducto(){ // producto o accesorio
        
    }

    // PARTIDAS

    public function crearPartida(){

    }
    public function editarPartida(){
        
    }
    public function eliminarPartida(){

    }
    public function aceptarSolicitudPartida(){

    }
    
    // PANEL DE CONTROL

    public function cambiarVista(){ // alternar entre vista del panel de control y vista estándar

    }
    

}